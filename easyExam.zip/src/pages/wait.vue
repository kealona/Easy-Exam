<template>
	<div>
		<div class="yk-wait-title">
			<span>{{ examInfo.examinationName }}</span>
		</div>
		<div class="yk-wait-container">
			<div class="yk-wait-instructions">
				<p>考试须知</p>
				<span>
					{{ examInfo.introduction }}
				</span>
			</div>
		</div>
		<div class="yk-exam-time">
			<button class="yk-button" v-if="isAccess" @click="jumpToExam">开始考试</button>
			<div v-else>
				<p>
					距离考试开始还有：
					<span>{{ minute }} : {{ second }}</span>
				</p>
			</div>
		</div>

	</div>
</template>

<script>
	import {
		initWsCollection
	} from '../utils/request/ws.js'
	const {
		dialog
	} = global.elRequire('electron')

	export default {
		name: 'Wait',

		data() {
			return {
				examName: '2022年高级软件工程师考试', //考试名称
				instructions: `1．考前三十分钟，考生需持符合报考规定的并与准考证显示信息一致的有效证件，进入规定的考场。

　　2．考试期间考生可携带物品：签字笔、铅笔、橡皮、二十四色彩笔（包含黑色、蓝色、棕色、绿色、灰色、橙色、粉色、紫色、红色、黄色）铅笔盒、塑料瓶装水、药品、纸巾和准考证。

　　3．考试期间需放在指定区域的禁止携带物品：处于关闭状态下的手机、相机或任何其他电子产品、字典、笔记本、修正液/修正带等、纸张、书包、手提包、行李箱。

　　4．考场内不得相互借用文具。严禁在考场内饮食。

　　5．考生入场后，按号入座，将本人《准考证》放在课桌上，以便核验。`, //考试须知
				isAccess: false, //是否可以进入考试
				minutes: 0,
				seconds: 0,
				remainTime: 5,
				startTime: '', //考试开始时间
				endTime: '', //考试结束时间
				timer: '', //倒计时定时器
				examInfo: {}, //考试信息
				examId: 0, //考试id
			}
		},

		computed: {
			//分钟倒计时
			minute() {
				return this.formateNum(this.minutes)
			},
			//秒数倒计时
			second() {
				return this.formateNum(this.seconds)
			},
			/* //计算考试剩余时间
			remainTime() {
				let start = new Date(this.startTime)
				let nowTime = new Date().getTime()
				return (nowTime - start) / 1000
			} */
		},

		watch: {
			second: {
				handler(newValue) {
					this.formateNum(newValue)
				}
			},
			minute: {
				handler(newValue) {
					this.formateNum(newValue)
				}
			}
		},

		created() {
			//获取考试信息
			let {
				examId
			} = this.$route.query
			//创建持久连接
			localStorage.setItem('examId', examId)
			this.createWebsocketCollection(examId)
			this.examId = examId
			this.getEaxamInfo()
		},

		mounted() {

		},

		methods: {
			/**
			 * 获取考试信息
			 */
			getEaxamInfo() {
				this.$http.get(`/examinations/examination/id/${this.examId}`)
					.then((res) => {
						if (res.data.code != 200) {
							this.$message.error('请检查网络设置')
						} else {
							this.examInfo = res.data.data
							this.startTime = res.data.data.startTime
							this.endTime = res.data.data.endTime

							this.paperId = res.data.data.paperId

							let start = new Date(this.startTime)
							let nowTime = new Date()
							this.remainTime = (start - nowTime) / 1000

							//初始化倒计时器
							if (this.remainTime > 0) {
								this.minutes = Math.floor(this.remainTime / 60) % 60
								this.seconds = Math.floor(this.remainTime % 60)
								this.countDown()
							} else {
								this.isAccess = true
							}
						}
					})
			},
			/**
			 * 创建websocket连接
			 */
			createWebsocketCollection(examId) {
				initWsCollection((text) => {
					//接收到消息的回调
					console.log(text)
					if (text.type == 2) {
						this.$alert(text.data, '警告', {
							confirmButtonText: '确定',
							callback: action => {
								/* this.$message({
									type: 'info',
									message: `action: ${ action }`
								}); */
							}
						});
					}

				})
			},
			//格式化时间
			formateNum(num) {
				return num < 10 ? '0' + num : '' + num
			},
			//设置定时器
			countDown() {
				clearInterval(this.timer)
				this.timer = setInterval(() => {
					//倒计时结束，清除定时器，可以进入考试
					if (this.minutes == 0 && this.seconds == 0) {
						//显示【进入考试】按钮
						this.isAccess = true
						//清除定时器
						clearInterval(this.timer)
					} else if (this.minutes != 0 && this.seconds == 0) {
						//如果秒数为0，但分钟不为0，秒数重新计算
						this.minutes -= 1
						this.seconds = 59
					} else {
						this.seconds -= 1
					}
				}, 1000)
			},
			//跳转到考试界面
			jumpToExam() {
				this.$router.replace({
					path: '/exam',
					query: {
						paperId: this.paperId,
						endTime: this.endTime,
						examId: this.examId
					}
				})
			}
		}
	}
</script>

<style scoped="scoped" lang="scss">
	.yk-wait-title {
		font-size: 25px;
		color: $--color-white;
		background-color: $--color-primary;
		font-weight: lighter;
		width: 100%;
		height: 75px;
		line-height: 75px;
		text-align: center;
	}

	.yk-wait-container {
		display: flex;
		justify-content: center;
		align-items: center;
		height: 65vh;
	}

	.yk-wait-instructions {
		border: 1px solid #faad14;
		border-radius: $--border-radius-large;
		width: 50%;
		padding: 20px;
		/* box-shadow: $--shadow-primary; */
		background-color: #fffbe6;

		p {
			text-align: center;
			font-size: 19px;
		}

		span {
			word-wrap: wrap;
		}
	}

	.yk-exam-time {
		display: flex;
		justify-content: center;

		span {
			font-weight: bold;
		}

	}

	.yk-button {
		background-color: $--color-primary;
		cursor: pointer;
		color: $--color-white;
		width: 200px;
		height: 45px;
		border-color: #80b7ff;
		border-radius: $--border-radius-medium;
		border: none;
		transition: all .2s ease-in-out;
		position: absolute;
		bottom: 100px;
		left: 50%;
		transform: translateX(-50%);

		&:focus {
			outline: none;
		}

		&:hover {
			background-color: mix($--color-white, $--color-primary, 30%) !important;
		}
	}
</style>
