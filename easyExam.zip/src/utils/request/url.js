//后端基本路径
export const baseURL = 'http://192.168.50.123:8000/'

//后端websocket路径
export const wsURL = 'ws://192.168.50.123:8000/'