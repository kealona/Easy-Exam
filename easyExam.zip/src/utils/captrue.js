/* const pcap = require('pcap') */

//截获数据包
export const getNetDevices = function () {
	console.log('获取数据包')
}